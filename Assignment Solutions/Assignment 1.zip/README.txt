# Assignment 1 – CO1 (Fare Logic)

This package contains one separate Word document for each Task 1–12.

Before submission:
1. Fill in your name and register number in each document.
2. Create the required GitHub repository: `DSA01-<RegisterNumber>-Assignment1`.
3. Add one folder per task containing its `.cpp` source, input data and your actual output screenshots.
4. Compile with `g++ -std=c++17 -Wall -Wextra <file.cpp> -o <program>` and run each program.
5. Record your actual compiler version (`g++ --version`) and actual warnings/output. Do not claim execution evidence until you have run it.
6. Add the GitHub URL to the cover fields and README.

Important assumptions:
- Peak periods are [08:00, 10:00) and [17:00, 20:00), so 10:00 and 20:00 are off-peak.
- Money is stored in integer paise.
- The assignment does not state the student/senior concession percentage. Task 1 flags this missing policy instead of presenting an invented rate as a fact. Task 5 gives 10% only as a configurable example assumption.
