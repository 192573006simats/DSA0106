# Assignment 1 – CO1 (Fare Logic)

This repository contains the separate Word documents for Tasks 01–12.

## Folder structure

```text
Assignment-1/
├── README.md
└── Tasks/
    ├── Task01_CO1_Object_Analysis/
    │   └── Task01_CO1_Object_Analysis.docx
    ├── Task02_CO1_Tokens_Constants/
    │   └── Task02_CO1_Tokens_Constants.docx
    └── ... (Tasks 03–12)
```

## Before submission

1. Fill in your name and register number in each document.
2. Add the required `.cpp` source files, input data, and actual output screenshots inside the corresponding task folders, if required by your faculty.
3. Compile using `g++ -std=c++17 -Wall -Wextra <file.cpp> -o <program>`.
4. Record your actual compiler version (`g++ --version`) and actual warnings/output. Do not claim execution evidence until you have run the program.
5. Add your GitHub repository URL to the relevant cover fields.

## Notes

- Peak periods are [08:00, 10:00) and [17:00, 20:00), so 10:00 and 20:00 are off-peak.
- Money is stored in integer paise.
- The assignment does not state the student/senior concession percentage. Task 1 flags this missing policy instead of presenting an invented rate as a fact. Task 5 gives 10% only as a configurable example assumption.

**This ZIP contains the Word task documents only. Add your own source code and genuine output screenshots before final submission if they are required.**
