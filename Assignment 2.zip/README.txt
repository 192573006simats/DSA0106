ASSIGNMENT 2 – CO2
Seven separate Word documents are included (Q1–Q7).

Formatting: first page contains only the course/assignment/task headings. No student name, register number, or GitHub field has been added.

Before submission:
- Compile and run each C++ program with your compiler.
- Capture actual output screenshots.
- For Q2, compile the dangling-reference example only to capture the diagnostic; do not run or dereference it.
- For Q6, measure timings on your computer at -O0 and -O2 and enter actual values.
- For Q7, run the same test cases on both implementations and enter actual timings.
- Add source files and evidence to your GitHub repository as required by the assignment brief.
